module.exports = window.Project = {
    dataCenterApi: 'https://public-api.wazoku.com/api/v1.3/',
    api: 'https://public-api.wazoku.com/api/v1.3/',
    ga: '',
    apiVersion: '1.3',
};
