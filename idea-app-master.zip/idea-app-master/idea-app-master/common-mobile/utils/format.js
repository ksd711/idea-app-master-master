const Format = window.Format = Object.assign({}, require('./base/_format'), {});

export default Format;
