import base from './base/format-base';

export default Object.assign({}, base, {});
