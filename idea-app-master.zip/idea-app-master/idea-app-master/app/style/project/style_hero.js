
module.exports = {
    heroIcon: {
        color: 'white',
        fontSize: 20,
    },
    heroText: {
        color: 'white',
        fontFamily: 'ProximaNova-Regular',
    },
    heroThumbIcon: {
        marginRight: 10,
    },
    heroIconAnimation: {
        width: 30,
        height: 30,
    },
};
