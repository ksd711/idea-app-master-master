// Here you can override any style variable and it'll only be overridden in ios - e.g. inputHeight
module.exports = {
    inputHeight: 54,
};
