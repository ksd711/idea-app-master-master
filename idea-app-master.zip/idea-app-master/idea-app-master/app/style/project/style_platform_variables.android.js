// Here you can override any style variable and it'll only be overridden in android - e.g. inputHeight
module.exports = {
    inputHeight: 64,
};
