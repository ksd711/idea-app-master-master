import { PureComponent } from 'react';

export default class extends PureComponent {
  static displayName = 'NotificationTeamMemberRequestAccepted';

  static propTypes = {
      first: propTypes.bool,
      notification: propTypes.shape({
          ideaId: propTypes.string,
          ideaName: propTypes.string,
          message: propTypes.string,
      }),
      goToIdea: propTypes.func,
      unread: propTypes.bool,
  }

  render() {
      const { props: { first, notification: { ideaId, ideaName, messageStart, messageEnd }, unread, goToIdea } } = this;
      const user = AccountStore.getUser();
      // TODO attempt to get users avatar image from display name..
      return (
          <TouchableOpacity onPress={() => goToIdea(ideaId)}>
              <Row style={[unread ? Styles.notificationListItemUnread : Styles.notificationListItem, first ? Styles.notificationListItemFirst : {}]}>
                  <View>
                      {user.thumbnail ? (
                          <FastImage source={{ uri: user.thumbnail, borderRadius: Styles.avatarPlaceholder.borderRadius }} style={Styles.avatarPlaceholder} />
                      ) : (
                          <View style={Styles.avatarPlaceholder}>
                              <Text style={Styles.avatarInitial}>{user.display_name ? user.display_name[0].toUpperCase() : ''}</Text>
                          </View>
                      )}
                  </View>

                  <Flex>
                      <Row style={Styles.pr10}>
                          <Text style={Styles.notiificationText}>
                              {messageStart}
                              <Text style={{ fontWeight: 'bold' }}>{ideaName}</Text>
                              {messageEnd}
                          </Text>
                      </Row>
                  </Flex>
              </Row>
          </TouchableOpacity>
      );
  }
}