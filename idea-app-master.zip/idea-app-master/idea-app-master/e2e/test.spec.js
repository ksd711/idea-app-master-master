// Tests are required here in the order you want them to execute in
require('./basic-test');
